/*********************************
Josh Kennerly
jdkenne
Lab 4
Lab Section 003
Nushrat
********************************/

The secret number is 1021!
