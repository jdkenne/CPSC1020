#include <stdio.h>

int main (void) 
{
printf("I am pumped to learn more about C and C++!\n");

return 0;
}
