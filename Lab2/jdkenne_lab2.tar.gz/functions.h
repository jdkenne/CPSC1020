/**********************************
Joshua Kennerly 
CPSC 1021, Lab Section 003, F19
jdkenne@clemson.edu
Feaster
**********************************/
#include <stdio.h>
#include <stdlib.h>
#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void sizeOfName(char** name);
void printSizeOfName(int *firstCount, int *lastCount, char** name);
void reverseString(int *first, int *last, char** name);

#endif
